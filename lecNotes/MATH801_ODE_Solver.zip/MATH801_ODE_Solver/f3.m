function q=f3(t,V1,tau, Vb0, omega); 
q=(Vb0./tau).*sin(omega.*t)-V1./tau;
