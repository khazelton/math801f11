simulink
p=AbsSin/10000;
plot(t,y,'g',p,'r')
title('Simulink results, plotted in Matlab')
xlabel('time')
lengend('Output','Input')
