function c = nnltyell
%NNLTYELL Neural Network Design utility function.

% Copyright 1994-2002 PWS Publishing Company and The MathWorks, Inc.
% $Revision: 1.6 $
% First Version, 8-31-95.

%==================================================================

c = [1 1 0.6]*0.95;
