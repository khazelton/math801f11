function c = nnltgray
%NNLTGRAY Neural Network Design utility function.

% Copyright 1994-2002 PWS Publishing Company and The MathWorks, Inc.
% $Revision: 1.6 $
% First Version, 8-31-95.

%==================================================================


c = [0.68 0.68 0.68];
