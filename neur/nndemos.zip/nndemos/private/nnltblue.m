function c=nnltblue
%NNLTBLUE Neural Network Design utility function.

% Copyright 1994-2002 PWS Publishing Company and The MathWorks, Inc.
% $Revision: 1.6 $

c = [0.5 0.5 1];
