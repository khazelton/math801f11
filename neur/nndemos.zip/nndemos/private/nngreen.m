function c = nngreen
%NNGREEN Green used by Neural Network Toolbox GUI.
  
%  NNGREEN returns rgb triple for green.

% Mark Beale 6-4-94
% Copyright 1994-2002 PWS Publishing Company and The MathWorks, Inc.
% $Revision: 1.7 $

c = [0 0.7 0];
